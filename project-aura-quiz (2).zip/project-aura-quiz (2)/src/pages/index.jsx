
import React from 'react';

export default function Home() {
  return (
    <div style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h1>Welcome to Project AURA: Companion Quiz</h1>
      <p>This is your demo prototype app.</p>
    </div>
  );
}
